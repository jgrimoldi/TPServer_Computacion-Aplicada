#!/bin/bash

# Funcion de ayuda
function mostrar_ayuda {
	echo -e "\n Uso: $0 [origen] [destino] \n"
	echo "Opciones:"
	echo "	-h,--help,--ayuda	Esta ayuda."
	echo
	echo "Este script realiza un backup completo del directorio de origen en destino"
	exit 0
}

# Validar directorios
function validar_directorio {
	local DIR=$1
	local TIPO=$2

	if [[ ! -d "$DIR" ]]; then
		echo "Error: el directorio de $TIPO '$DIR' no existe o no está disponible"
		exit 1
	fi
}

# Mostrar ayuda
if [[ "$1" == "-h" || "$1" == "--help" || "$1" == "--ayuda" ]]; then
	mostrar_ayuda
fi

# Validar argumentos entrada con 2 argumentos
if [[ $# -ne 2 ]]; then
	echo -e "\n Error: se requieren dos argumentos \n"
	mostrar_ayuda
fi

ORIGEN=$1
DESTINO=$2

# Validar que existan los directorios y esten montados
validar_directorio "$ORIGEN" "origen"
validar_directorio "$DESTINO" "destino"

# Generar nombre del backup
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz
ARCHIVO_DESTINO="${DESTINO}/${NOMBRE}"

#Crear backup
echo "Creando el backup de '$ORIGEN' en '$ARCHIVO_DESTINO'"
tar -czf "$ARCHIVO_DESTINO" -C "$(dirname "$ORIGEN")" "$(basename "$ORIGEN")"

if [[ $? -eq 0 ]]; then
	echo "Backup creado exitosamente en '$ARCHIVO_DESTINO'."
else
	echo "Error al crear el backup."
	exit 1
fi

